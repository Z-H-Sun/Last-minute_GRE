# encoding: GBK
# Ruby 2.2.0

for i in '01'..'25'
  puts
  f = open("Dic_#{i}\\Dic_#{i}_999.txt")
  eval("@list = #{f.read}")
  f.close
  
  f = open("Dic_#{i}\\Dic_#{i}_Exmp.txt")
  eval("@hash = #{f.read}")
  f.close
  
  @exmp = Hash.new
  for j in @list
    next unless @hash[j[0]].empty?
    str = `baidutranslation #{j[0]}`
    print "\033[0m\r Processing: Word List #{i}, #{j[0]}                   "
    if str.include?('[Warning]')
      puts "\033[1;31m\r Failed:     Word List #{i}, #{j[0]}"
	  next
    end
    el = str.split('����������Դ������')[1].split(/\n\d+\n\n\n/)
    el.map! {|e| e.split("\n\n")[0..2] unless e.empty?}
	el[0] = ['---------------------------------------', '', '��ע��, ��һ��������Դ������.']
    @exmp[j[0]] = el[0..1]
  end
  f = open("Dic_#{i}\\Dic_#{i}_Exmp.txt", 'w')
  f.write(@hash.merge(@exmp))
  f.close
end
system('pause')
