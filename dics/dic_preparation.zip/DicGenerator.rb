# encoding: GBK
# Ruby 2.2.0

f = open('Dic.txt')

@listnum = 0

f.readlines.each do |l|
  num = nil
  if l[0,9] == 'Word List'
    num = l[-4, 3].to_i
  end
  if l[0,2] == '��¼' then num = 26; @chs = ''; @exmp = '����:' end

  unless num.nil? or num == @listnum
    unless @listnum.zero?
      @list.push([@word, @explanation])
      @list.delete_at(0)
      @dicfile.write(@list.to_s)
      @dicfile.close
    end
    @listnum = num; @list = []
    unless File.exist?('Dic_%02d' % num) then Dir.mkdir('Dic_%02d' % num) end
    @dicfile = open('Dic_%02d\\Dic_%02d_999.txt' % [num, num], 'w')
    next
  end

  #

  if @listnum == 26
    if l.include?('��')
      @list.push([@word, @explanation])
      @word = l.split('��')[0]; @chs = l.split('��')[1].strip; @explanation = []
    else
      if @chs.empty?
        @chs = l.strip
      else
        @exmp += ' ' + l.strip
        if ['.', '"', '?'].include?(l.strip[-1]) then @explanation.push([@exmp, @chs]); @exmp = '����:' end
      end
    end
    next
  end

  #

  if l[0].ord > 96 and l[0].ord < 123 and l.include?('Ӣ')
    @list.push([@word, @explanation])
    @word = l.split[0]; @explanation = []
  end
  if l.include?(' Ӣ') or l.include?('Ӣ ') then @eng = '[' + l.split('Ӣ', 2)[1].strip; @eng = @eng.insert(@eng.rindex('.', 15) + 1, ']') end
  if l[0] == '/'
    unless l.include?(' ��') or l.include?('�� ') then @eng += ' ' + l.split('/', 3)[2].strip end
  end
  if l.include?(' ��') or l.include?('�� ') then @chs = l.split('��', 2)[1].strip; @explanation.push([@eng, @chs]) end
end
@list.push([@word, @explanation])
@list.push([@word, @explanation])
@list.delete_at(0)
@dicfile.write(@list.to_s)
@dicfile.close
f.close