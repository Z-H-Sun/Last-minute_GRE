﻿Imports System.Windows.Forms

Module Module1

    Private WithEvents Timer1 As New Timer()

    Private Sub Timer1_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles Timer1.Tick
        Console.Write("[Warning]: Timeout. Please check your internet settings.")
        End
    End Sub

    Sub Main()
        Dim webb As New WebBrowser
        Try
            webb.Navigate("http://fanyi.baidu.com/#en/zh/" & My.Application.CommandLineArgs.ToArray(0))
        Catch ex As Exception
            Console.Write("[Warning]: Word not specified.")
            End
        End Try
        Timer1.Interval = 10000
        Timer1.Start()
        Do
            Try
                For Each i In webb.Document.GetElementById("cont-sample").Children(0).Children
                    If InStr(i.GetAttribute("classname").ToString, "double-sample") Then
                        Console.Write(i.InnerText)
                        Exit Do
                    End If
                Next
            Catch ex As Exception
            End Try
            Application.DoEvents()
        Loop
    End Sub
End Module
