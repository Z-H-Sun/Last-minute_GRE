# encoding: GBK
# Ruby 2.2.0

for i in '01'..'25'
  puts
  f = open("Dic_#{i}\\Dic_#{i}_999.txt")
  eval("@list = #{f.read}")
  f.close
  @exmp = Hash.new
  for j in @list
    str = `baidutranslation #{j[0]}`
    print "\033[0m\r Processing: Word List #{i}, #{j[0]}                   "
    if str.include?('[Warning]')
      puts "\033[1;31m\r Failed:     Word List #{i}, #{j[0]}"
    end
    el = str.split('����������Դ������')[0].split(/\n\d+\n\n\n/); el.delete_at(0)
    el.map! {|e| e.split("\n\n")[0..2]}
    @exmp[j[0]] = el
  end
  f = open("Dic_#{i}\\Dic_#{i}_Exmp.txt", 'w')
  f.write(@exmp.to_s)
  f.close
end
system('pause')
